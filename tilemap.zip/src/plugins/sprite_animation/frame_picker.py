"""
Frame Picker — click tiles on a spritesheet to add animation frames.

Displays the spritesheet with a grid overlay. Left-click toggles a
tile in/out of the current clip (add vs remove). Ctrl+click jumps the
timeline to a keyframe that uses that cel. Used tiles are tinted green;
the active keyframe also has a blue outline.
"""

from __future__ import annotations

import math
from typing import Callable, Optional, Set, Tuple

import pygame
from utils.font_manager import font_manager, FontWeight, FontStyle
from pygame import Rect

TOP_TITLE_H = 22
TOP_BAR_TOTAL = 42


# ---------------------------------------------------------------------------
# Inline theme constants (avoids hard dependency on widgets.ui.theme)
# ---------------------------------------------------------------------------
_COLORS = {
    "bg": (25, 27, 30),
    "grid": (255, 255, 255),
    "hover": (220, 180, 80),
    "highlight": (80, 180, 120),
    "border": (60, 62, 65),
    "text": (230, 230, 230),
    "text_dim": (140, 140, 140),
    "header": (40, 42, 46),
    "index_bg": (0, 0, 0),
    "input_bg": (30, 32, 38),
    "btn_active": (50, 70, 110),
    "filter_mask": (0, 0, 0),
    "focus": (100, 170, 255),
}


class FramePicker:
    """Spritesheet grid view — click tiles to select animation frames."""

    def __init__(
        self,
        rect: Rect,
        surface: pygame.Surface,
        tile_size: Tuple[int, int],
    ):
        self.rect = rect
        self.surface = surface
        self.tile_size = tile_size

        # Grid offset (for starting grid at a specific position in the spritesheet)
        # Must be initialized BEFORE _recalc_grid()
        self.grid_offset_x: int = 0
        self.grid_offset_y: int = 0

        self._recalc_grid()

        # View state
        self.offset_x: float = 0.0
        self.offset_y: float = 0.0
        self.zoom: float = 1.0

        # Interaction
        self.hover_index: int = -1
        self._panning = False
        self._pan_start = (0, 0)
        self._pan_start_offset = (0.0, 0.0)

        # Highlighted frames (belonging to the active animation)
        self.highlighted: Set[int] = set()
        self.focus_variant: int = -1

        self.filter_text: str = ""
        self.only_unused: bool = False
        self.editing_filter: bool = False
        self._filter_input_rect = Rect(0, 0, 0, 0)
        self._btn_unused_rect = Rect(0, 0, 0, 0)

        # Callback fired when user clicks a tile
        self.on_frame_clicked: Optional[Callable[[int], None]] = None

        # Fonts (created lazily so pygame.init() can happen anytime before draw)
        self._font: Optional[pygame.font.Font] = None
        self._font_sm: Optional[pygame.font.Font] = None

        # Checkerboard tile (8×8) cached
        self._checker: Optional[pygame.Surface] = None

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    def set_surface(
        self, surface: pygame.Surface, tile_size: Optional[Tuple[int, int]] = None
    ) -> None:
        self.surface = surface
        if tile_size:
            self.tile_size = tile_size
        self._recalc_grid()

    def set_highlighted(self, indices: Set[int]) -> None:
        self.highlighted = indices

    def set_focus_variant(self, variant_id: int) -> None:
        """Outline this tile to match the selected timeline frame (-1 clears)."""
        self.focus_variant = int(variant_id) if variant_id >= 0 else -1

    def scroll_variant_into_view(self, variant_id: int) -> None:
        """Pan so the given variant lies inside the sheet viewport (below the top bar)."""
        if variant_id < 0 or variant_id >= self.total_frames:
            return
        hr = self._tile_screen_rect(variant_id)
        if hr is None:
            return
        margin = 28
        inner = Rect(
            self.rect.x,
            self.rect.y + TOP_BAR_TOTAL,
            self.rect.w,
            self.rect.h - TOP_BAR_TOTAL,
        )
        if hr.width <= 0 or hr.height <= 0:
            return
        if hr.centerx < inner.left + margin:
            self.offset_x += (inner.left + margin) - hr.centerx
        elif hr.centerx > inner.right - margin:
            self.offset_x -= hr.centerx - (inner.right - margin)
        if hr.centery < inner.top + margin:
            self.offset_y += (inner.top + margin) - hr.centery
        elif hr.centery > inner.bottom - margin:
            self.offset_y -= hr.centery - (inner.bottom - margin)

    def resize(self, rect: Rect) -> None:
        self.rect = rect

    def set_grid_offset(self, offset_x: int, offset_y: int) -> None:
        """Set the grid offset for aligning the grid to a specific position in the spritesheet."""
        self.grid_offset_x = offset_x
        self.grid_offset_y = offset_y
        self._recalc_grid()

    def is_filter_input_active(self) -> bool:
        return self.editing_filter

    def handle_filter_keydown(self, event: pygame.event.Event) -> bool:
        if not self.editing_filter or event.type != pygame.KEYDOWN:
            return False
        if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_ESCAPE):
            self.editing_filter = False
            return True
        if event.key == pygame.K_BACKSPACE:
            self.filter_text = self.filter_text[:-1]
            return True
        if event.unicode and len(self.filter_text) < 20:
            self.filter_text += event.unicode
            return True
        return True

    # ------------------------------------------------------------------
    # Events
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> bool:
        mouse = pygame.mouse.get_pos()
        if not self.rect.collidepoint(mouse) and event.type not in (
            pygame.MOUSEBUTTONUP,
            pygame.MOUSEMOTION,
        ):
            return False

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(mouse) and mouse[1] < self.rect.y + TOP_BAR_TOTAL:
                if self._filter_input_rect.collidepoint(mouse):
                    self.editing_filter = True
                    return True
                if self._btn_unused_rect.collidepoint(mouse):
                    self.only_unused = not self.only_unused
                    return True
                self.editing_filter = False
                return True

        # Right-click drag to pan
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 3:
            if self.rect.collidepoint(mouse):
                if mouse[1] < self.rect.y + TOP_BAR_TOTAL:
                    return True
                self._panning = True
                self._pan_start = mouse
                self._pan_start_offset = (self.offset_x, self.offset_y)
                return True

        if event.type == pygame.MOUSEBUTTONUP and event.button == 3:
            if self._panning:
                self._panning = False
                return True

        if event.type == pygame.MOUSEMOTION and self._panning:
            dx = mouse[0] - self._pan_start[0]
            dy = mouse[1] - self._pan_start[1]
            self.offset_x = self._pan_start_offset[0] + dx
            self.offset_y = self._pan_start_offset[1] + dy
            return True

        # Left-click to select a frame
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if (
                self.rect.collidepoint(mouse)
                and mouse[1] >= self.rect.y + TOP_BAR_TOTAL
            ):
                idx = self._index_at(mouse)
                if (
                    idx >= 0
                    and self._tile_matches_filter(idx)
                    and self.on_frame_clicked
                ):
                    self.on_frame_clicked(idx)
                return True

        # Scroll to pan / Ctrl+scroll to zoom
        # Handles both mouse wheel and touchpad gestures
        if event.type == pygame.MOUSEWHEEL and self.rect.collidepoint(mouse):
            if mouse[1] < self.rect.y + TOP_BAR_TOTAL:
                return True
            mods = pygame.key.get_mods()
            if mods & (pygame.KMOD_LCTRL | pygame.KMOD_RCTRL):
                # Zoom mode: vertical scroll zooms, horizontal scroll pans
                old = self.zoom
                # Use vertical scroll for zoom
                if event.y != 0:
                    self.zoom *= 1.12 if event.y > 0 else 0.88
                    self.zoom = max(0.25, min(self.zoom, 8.0))
                    # Zoom toward mouse position
                    rel_x = mouse[0] - self.rect.x - self.offset_x
                    rel_y = mouse[1] - self.rect.y - self.offset_y
                    scale = self.zoom / old
                    self.offset_x -= rel_x * (scale - 1)
                    self.offset_y -= rel_y * (scale - 1)
                # Use horizontal scroll for panning (touchpad support)
                if event.x != 0:
                    self.offset_x += event.x * 30
            else:
                # Pan mode: vertical scroll pans Y, horizontal scroll pans X
                # Touchpad two-finger scroll sends both x and y
                if event.y != 0:
                    self.offset_y += event.y * 30
                if event.x != 0:
                    self.offset_x += event.x * 30
            return True

        # Keyboard shortcuts for zoom and pan (when mouse is over the frame picker)
        if event.type == pygame.KEYDOWN and self.rect.collidepoint(mouse):
            mods = pygame.key.get_mods()
            # Don't capture if Ctrl/Shift is held (let mouse wheel zoom handle it)
            if not (
                mods
                & (
                    pygame.KMOD_LCTRL
                    | pygame.KMOD_RCTRL
                    | pygame.KMOD_LSHIFT
                    | pygame.KMOD_RSHIFT
                )
            ):
                zoom_step = 1.15
                if event.key == pygame.K_EQUALS or event.key == pygame.K_PLUS:
                    # Zoom in
                    old = self.zoom
                    self.zoom *= zoom_step
                    self.zoom = min(self.zoom, 8.0)
                    # Zoom toward center of view
                    cx = self.rect.w // 2
                    cy = self.rect.h // 2
                    rel_x = cx - self.offset_x
                    rel_y = cy - self.offset_y
                    scale = self.zoom / old
                    self.offset_x -= rel_x * (scale - 1)
                    self.offset_y -= rel_y * (scale - 1)
                    return True
                elif event.key == pygame.K_MINUS:
                    # Zoom out
                    old = self.zoom
                    self.zoom /= zoom_step
                    self.zoom = max(self.zoom, 0.25)
                    cx = self.rect.w // 2
                    cy = self.rect.h // 2
                    rel_x = cx - self.offset_x
                    rel_y = cy - self.offset_y
                    scale = self.zoom / old
                    self.offset_x -= rel_x * (scale - 1)
                    self.offset_y -= rel_y * (scale - 1)
                    return True
                elif event.key == pygame.K_0:
                    # Reset zoom to 1x and center
                    self.zoom = 1.0
                    self.offset_x = 0.0
                    self.offset_y = 0.0
                    return True

                # Arrow keys for panning
                pan_amount = 20
                if event.key == pygame.K_LEFT:
                    self.offset_x += pan_amount
                    return True
                elif event.key == pygame.K_RIGHT:
                    self.offset_x -= pan_amount
                    return True
                elif event.key == pygame.K_UP:
                    self.offset_y += pan_amount
                    return True
                elif event.key == pygame.K_DOWN:
                    self.offset_y -= pan_amount
                    return True

        # Track hover
        if event.type == pygame.MOUSEMOTION:
            if self.rect.collidepoint(mouse):
                hi = self._index_at(mouse)
                if hi >= 0 and self._tile_matches_filter(hi):
                    self.hover_index = hi
                else:
                    self.hover_index = -1
            else:
                self.hover_index = -1

        return False

    # ------------------------------------------------------------------
    # Drawing
    # ------------------------------------------------------------------

    def draw(self, screen: pygame.Surface) -> None:
        self._ensure_fonts()
        clip = screen.get_clip()
        screen.set_clip(self.rect)

        # Background (checkerboard)
        self._draw_checker_bg(screen)

        tw, th = self.tile_size
        z = self.zoom
        img_x = self.rect.x + self.offset_x
        img_y = self.rect.y + self.offset_y
        scaled_w = int(self.surface.get_width() * z)
        scaled_h = int(self.surface.get_height() * z)

        # Draw scaled spritesheet
        if scaled_w > 0 and scaled_h > 0:
            scaled = pygame.transform.smoothscale(self.surface, (scaled_w, scaled_h))
            screen.blit(scaled, (img_x, img_y))

        # Grid lines (only within spritesheet bounds, starting from offset)
        cell_w = tw * z
        cell_h = th * z

        # Calculate spritesheet bounds on screen
        sheet_screen_rect = Rect(int(img_x), int(img_y), int(scaled_w), int(scaled_h))

        # Calculate grid start position (with offset applied)
        grid_start_x = img_x + (self.grid_offset_x * z)
        grid_start_y = img_y + (self.grid_offset_y * z)

        # Clip grid to spritesheet area
        grid_clip = sheet_screen_rect.clip(self.rect)
        if grid_clip.width > 0 and grid_clip.height > 0:
            grid_alpha_surf = pygame.Surface(
                (grid_clip.w, grid_clip.h), pygame.SRCALPHA
            )

            # Draw vertical lines
            for c in range(self.cols + 1):
                x_world = grid_start_x + c * cell_w
                x_local = int(x_world - grid_clip.x)
                if 0 <= x_local <= grid_clip.w:
                    pygame.draw.line(
                        grid_alpha_surf,
                        (*_COLORS["grid"], 40),
                        (x_local, 0),
                        (x_local, grid_clip.h),
                    )

            # Draw horizontal lines
            for r in range(self.rows + 1):
                y_world = grid_start_y + r * cell_h
                y_local = int(y_world - grid_clip.y)
                if 0 <= y_local <= grid_clip.h:
                    pygame.draw.line(
                        grid_alpha_surf,
                        (*_COLORS["grid"], 40),
                        (0, y_local),
                        (grid_clip.w, y_local),
                    )

            screen.blit(grid_alpha_surf, grid_clip.topleft)

        # Highlighted tiles (used in current animation)
        for idx in self.highlighted:
            col = idx % self.cols
            row = idx // self.cols
            hr = Rect(
                int(img_x + (self.grid_offset_x + col * tw) * z),
                int(img_y + (self.grid_offset_y + row * th) * z),
                int(cell_w),
                int(cell_h),
            )
            hl_surf = pygame.Surface((hr.w, hr.h), pygame.SRCALPHA)
            hl_surf.fill((*_COLORS["highlight"], 55))
            screen.blit(hl_surf, hr.topleft)
            pygame.draw.rect(screen, _COLORS["highlight"], hr, 1)

        # Dim tiles that fail the active filter (still visible for context)
        for idx in range(self.total_frames):
            if self._tile_matches_filter(idx):
                continue
            hr = self._tile_screen_rect(idx)
            if hr is None:
                continue
            if not self.rect.colliderect(hr):
                continue
            dim = pygame.Surface((hr.w, hr.h), pygame.SRCALPHA)
            dim.fill((*_COLORS["filter_mask"], 140))
            screen.blit(dim, hr.topleft)

        # Timeline-linked selection (distinct from "used in clip" green wash)
        if self.focus_variant >= 0 and self.focus_variant < self.total_frames:
            fhr = self._tile_screen_rect(self.focus_variant)
            if fhr is not None and self.rect.colliderect(fhr):
                pygame.draw.rect(screen, _COLORS["focus"], fhr, 3)

        # Hover highlight
        if self.hover_index >= 0:
            col = self.hover_index % self.cols
            row = self.hover_index // self.cols
            hr = Rect(
                int(img_x + (self.grid_offset_x + col * tw) * z),
                int(img_y + (self.grid_offset_y + row * th) * z),
                int(cell_w),
                int(cell_h),
            )
            pygame.draw.rect(screen, _COLORS["hover"], hr, 2)
            # Index label
            label = self._font_sm.render(str(self.hover_index), True, _COLORS["text"])
            lx = hr.x + 2
            ly = hr.y + 2
            bg_rect = Rect(
                lx - 1, ly - 1, label.get_width() + 4, label.get_height() + 2
            )
            bg = pygame.Surface((bg_rect.w, bg_rect.h), pygame.SRCALPHA)
            bg.fill((0, 0, 0, 160))
            screen.blit(bg, bg_rect.topleft)
            screen.blit(label, (lx, ly))

        # Top bar: title + filter row
        hdr = Rect(self.rect.x, self.rect.y, self.rect.w, TOP_TITLE_H)
        hdr_bg = pygame.Surface((hdr.w, hdr.h), pygame.SRCALPHA)
        hdr_bg.fill((*_COLORS["header"], 200))
        screen.blit(hdr_bg, hdr.topleft)
        title = self._font.render(
            f"Spritesheet  ({self.cols}×{self.rows})  Zoom: {self.zoom:.1f}x"
            f"  ·  click: add/remove  ·  Ctrl+click: select  ·  +/-: zoom  ·  arrows: pan",
            True,
            _COLORS["text"],
        )
        screen.blit(title, (self.rect.x + 6, self.rect.y + 3))

        row2 = Rect(
            self.rect.x,
            self.rect.y + TOP_TITLE_H,
            self.rect.w,
            TOP_BAR_TOTAL - TOP_TITLE_H,
        )
        row2_bg = pygame.Surface((row2.w, row2.h), pygame.SRCALPHA)
        row2_bg.fill((*_COLORS["header"], 220))
        screen.blit(row2_bg, row2.topleft)

        self._filter_input_rect = Rect(
            row2.x + 6, row2.y + 4, min(140, row2.w - 100), 18
        )
        fi_bg = _COLORS["btn_active"] if self.editing_filter else _COLORS["input_bg"]
        pygame.draw.rect(screen, fi_bg, self._filter_input_rect, border_radius=3)
        pygame.draw.rect(
            screen, _COLORS["border"], self._filter_input_rect, 1, border_radius=3
        )
        ft = self.filter_text + (
            "|" if self.editing_filter and (pygame.time.get_ticks() // 400) % 2 else ""
        )
        lab = "id…" if not self.filter_text and not self.editing_filter else ft
        col = (255, 220, 100) if self.editing_filter else _COLORS["text"]
        screen.blit(
            self._font_sm.render(lab, True, col),
            (self._filter_input_rect.x + 4, self._filter_input_rect.y + 3),
        )

        self._btn_unused_rect = Rect(
            self._filter_input_rect.right + 8, row2.y + 4, 86, 18
        )
        ub = _COLORS["btn_active"] if self.only_unused else _COLORS["input_bg"]
        pygame.draw.rect(screen, ub, self._btn_unused_rect, border_radius=3)
        pygame.draw.rect(
            screen, _COLORS["border"], self._btn_unused_rect, 1, border_radius=3
        )
        ut = "Unused only" if self.only_unused else "All tiles"
        screen.blit(
            self._font_sm.render(ut, True, _COLORS["text"]),
            (self._btn_unused_rect.x + 4, self._btn_unused_rect.y + 3),
        )

        screen.set_clip(clip)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _recalc_grid(self) -> None:
        """Recalculate grid dimensions based on tile size and offset."""
        tw, th = self.tile_size
        # Calculate available space after offset
        available_w = self.surface.get_width() - self.grid_offset_x
        available_h = self.surface.get_height() - self.grid_offset_y
        self.cols = max(1, available_w // tw)
        self.rows = max(1, available_h // th)
        self.total_frames = self.cols * self.rows

    def _tile_matches_filter(self, idx: int) -> bool:
        if self.only_unused and idx in self.highlighted:
            return False
        q = self.filter_text.strip().lower()
        if not q:
            return True
        return q in str(idx).lower()

    def _tile_screen_rect(self, idx: int) -> Optional[Rect]:
        if idx < 0 or idx >= self.total_frames:
            return None
        tw, th = self.tile_size
        z = self.zoom
        col = idx % self.cols
        row = idx // self.cols
        img_x = self.rect.x + self.offset_x
        img_y = self.rect.y + self.offset_y
        cell_w = tw * z
        cell_h = th * z
        return Rect(
            int(img_x + (self.grid_offset_x + col * tw) * z),
            int(img_y + (self.grid_offset_y + row * th) * z),
            int(cell_w),
            int(cell_h),
        )

    def _index_at(self, mouse: Tuple[int, int]) -> int:
        """Return tile index at the given screen position or -1."""
        if mouse[1] < self.rect.y + TOP_BAR_TOTAL:
            return -1
        z = self.zoom
        tw, th = self.tile_size
        W = float(self.surface.get_width())
        H = float(self.surface.get_height())

        # Convert mouse to spritesheet pixel coordinates
        rel_x = (mouse[0] - self.rect.x - self.offset_x) / z
        rel_y = (mouse[1] - self.rect.y - self.offset_y) / z

        # ~1 screen pixel in texture space — fixes float overshoot on right/bottom at zoom
        eps_tex = max(0.25, 0.5 / max(z, 0.01))

        if rel_x < 0 or rel_y < 0:
            return -1
        if rel_x >= W and rel_x < W + eps_tex:
            rel_x = max(0.0, W - 1e-6)
        if rel_y >= H and rel_y < H + eps_tex:
            rel_y = max(0.0, H - 1e-6)
        if rel_x >= W or rel_y >= H:
            return -1

        grid_rel_x = rel_x - self.grid_offset_x
        grid_rel_y = rel_y - self.grid_offset_y

        if grid_rel_x < 0 or grid_rel_y < 0:
            return -1

        gw = float(self.cols * tw)
        gh = float(self.rows * th)
        # Nudge picks that land on the inner edge of the last cell (float / scale artifacts)
        if grid_rel_x >= gw and grid_rel_x < gw + eps_tex:
            grid_rel_x = max(0.0, gw - 1e-6)
        if grid_rel_y >= gh and grid_rel_y < gh + eps_tex:
            grid_rel_y = max(0.0, gh - 1e-6)
        if grid_rel_x >= gw or grid_rel_y >= gh:
            return -1

        col = int(math.floor(grid_rel_x / tw))
        row = int(math.floor(grid_rel_y / th))

        if 0 <= col < self.cols and 0 <= row < self.rows:
            return row * self.cols + col
        return -1

    def _ensure_fonts(self) -> None:
        if self._font is None:
            self._font = font_manager.get_font("noto", 13, FontWeight.REGULAR)
        if self._font_sm is None:
            self._font_sm = font_manager.get_font("noto", 11, FontWeight.REGULAR)

    def _draw_checker_bg(self, screen: pygame.Surface) -> None:
        if self._checker is None:
            sz = 8
            self._checker = pygame.Surface((sz * 2, sz * 2))
            c1, c2 = (35, 35, 35), (45, 45, 45)
            self._checker.fill(c1)
            pygame.draw.rect(self._checker, c2, (sz, 0, sz, sz))
            pygame.draw.rect(self._checker, c2, (0, sz, sz, sz))
        for y in range(self.rect.y, self.rect.bottom, self._checker.get_height()):
            for x in range(self.rect.x, self.rect.right, self._checker.get_width()):
                screen.blit(self._checker, (x, y))
